package com.pc.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.pc.dao.PCdao;
import com.pc.model.pcmodel;

@Controller
@RequestMapping(value="/PleaseCome")
public class PCcontroller {
	
	@Autowired
	PCdao dao;
	
	
	@RequestMapping(value="/all")
	public String getCustomerMenu() {
		return "all";
	}
	
	@RequestMapping(value="/add", method=RequestMethod.GET)
	public ModelAndView addpc() {
		pcmodel p = new pcmodel();
		return new ModelAndView("success", "p", p);		
	}
	
	@RequestMapping(value="/success",method=RequestMethod.POST)
	public void addsuccess(@ModelAttribute("add") pcmodel p) {
		dao.addpc(p);
	}
	
	@RequestMapping(value="/show", method=RequestMethod.GET)
	public ModelAndView addshow(@RequestParam("id")int id) {
		pcmodel p = dao.getpc(id);
		return new ModelAndView("success", "p", p);		
	}

}
