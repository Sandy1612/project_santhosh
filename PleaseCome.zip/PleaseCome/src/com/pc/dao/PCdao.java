package com.pc.dao;

import java.util.HashMap;
import java.util.Map;

import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.pc.model.pcmodel;

@Repository
@Transactional
public class PCdao {
	
	
	Map<Integer, pcmodel> m=new HashMap<Integer, pcmodel>();
	
	
	public void addpc(pcmodel p) {
		
		m.put(p.getId(), p);
	}
	
	public pcmodel getpc(int id) {
		
		
		for(Map.Entry<Integer,pcmodel> it: m.entrySet())
		{
			pcmodel p=m.get(it.getKey());
			
			if(p.getId()==id)
			{
				return p;
			}					
		}
		return null;
		
		
	}
	
	
}
