package com.emp.dao;

import java.util.HashMap;
import java.util.Map;

import com.emp.bean.Employee;



public class EmpDAO implements IEmpDAO {

	HashMap<String,Employee> acuntMap = new HashMap<String,Employee>();

	Employee e = new Employee();
	
	
	public boolean createAccount(Employee e)
	{		
		acuntMap.put(e.getAcunt_num(), e);
		return true; 
	   
	    
	}

	
	public double showBalance(String acunt_num) 
	{
						
		e=acuntMap.get(acunt_num);
		
		return e.getBalance();
		
			
	}

	
	public boolean deposite(double temp,String acunt_num) 
	{
		e=acuntMap.get(acunt_num);
		e.setBalance(temp);
		e.setHist(e.getHist()+"amount is deposited into the account and the balance is "+temp+"\n");
		acuntMap.put(acunt_num, e);
		return true;
		
	}

	
	public boolean withdraw(double temp,String acunt_num) 
	{
		e=acuntMap.get(acunt_num);
		e.setBalance(temp);
		e.setHist(e.getHist()+"amount is withdrawn from the account and the balance is "+temp+"\n");
		acuntMap.put(acunt_num, e);
		return true;
	}

	
	public String printTransaction(String acunt_num) 
	{
		e=acuntMap.get(acunt_num);
		return e.getHist();
		
	}

	
	/*public void fundTransfer() {
		
		
	}*/

	public boolean check(String acunt_num, String pin){
		
		boolean f = false;
		for(Map.Entry<String,Employee> it: acuntMap.entrySet())
		{
			e=acuntMap.get(it.getKey());
			
			if(e.getAcunt_num().equals(acunt_num) && e.getPin().equals(pin) && f==false)
			{
				f=true;
			}					
		}
		return f;
		
	}

	
	public boolean check(String acunt_num){
		
		boolean f = false;
		
		for(Map.Entry<String,Employee> it: acuntMap.entrySet())
		{
			e=acuntMap.get(it.getKey());
			
			if(e.getAcunt_num().equals(acunt_num) && f==false)
			{
				f=true;
			}					
		}
		return f;
		
	}

}