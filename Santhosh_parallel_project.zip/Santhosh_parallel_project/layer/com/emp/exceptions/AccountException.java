package com.emp.exceptions;

public class AccountException extends Exception {

	public AccountException(String excep){
		
		//super(excep);
		System.out.println("Exception occured"+getMessage());
		
	}
}
