package com.emp.bean;

public class Employee {
	
	private String pan;
	private String aadhar;
	private String ph_num;
	private String ename;
	private String acunt_num;
	private double balance;
	private String pin;
	private String hist;
	
	
	public String getAcunt_num() {
		return acunt_num;
	}
	public void setAcunt_num(String acunt_num) {
		this.acunt_num = acunt_num;
	}

	
	
	
	public String getpan() {
		return pan;
	}
	public void setpan(String pan) {
		this.pan = pan;
	}
	
	public String getPh_num() {
		return ph_num;
	}
	public void setPh_num(String ph_num) {
		this.ph_num = ph_num;
	}
	public String getaadhar() {
		return aadhar;
	}
	public void setaadhar(String aadhar) {
		this.aadhar = aadhar;
	}
	public String getEname() {
		return ename;
	}
	public void setEname(String ename) {
		this.ename = ename;
	}
	
	@Override
	public String toString() {
		return "Employee [pan=" + pan + ", aadhar=" + aadhar + ", ph_num="
				+ ph_num + ", ename=" + ename + "]";
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public String getPin() {
		return pin;
	}
	public void setPin(String pin) {
		this.pin = pin;
	}
	public String getHist() {
		return hist;
	}
	public void setHist(String hist1) {
		this.hist = hist1;
	}
	
	
	
	
	
	
	}
	
	
