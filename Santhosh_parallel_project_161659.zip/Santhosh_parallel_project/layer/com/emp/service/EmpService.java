package com.emp.service;

import java.util.regex.Pattern;

import com.emp.bean.Employee;
import com.emp.dao.EmpDAO;

public class EmpService implements IEmpService {

	
	Employee e = new Employee();
	EmpDAO dao = new EmpDAO();
	public String acunt_num = e.getAcunt_num();
	
	
	
	
	public boolean createAccount(Employee e)
	{
		
		return dao.createAccount(e);
		
	}
	public double showBalance(String acunt_num)
	{
		return dao.showBalance(acunt_num);
	}
	public boolean deposite(double dep,String acunt_num)
	{
		double temp = dao.showBalance(acunt_num)+dep;
		return dao.deposite(temp,acunt_num);
		
	}
	public boolean withdraw(double wit,String acunt_num)
	{
		double temp = dao.showBalance(acunt_num)-wit;
		return dao.withdraw(temp,acunt_num);		
	}
	public String printTransaction(String acunt_num)
	{
		return dao.printTransaction(acunt_num);
	}
	/*public void fundTransfer()
	{
		
	}*/
	
		
	public boolean check(String acunt_num,String pin){
		
		return dao.check(acunt_num,pin);
	}
	
    public boolean check(String acunt_num){
		
		return dao.check(acunt_num);
	}
	
	public boolean valename(String ename) 
	{
		
		return Pattern.matches("[a-zA-Z\\s\\.]*",ename);
	}
	public boolean valpan(String pan) 
	{
		return Pattern.matches("[A-Z]{5}[0-9]{4}[A-Z]{1}",pan);
	}
	public boolean valph_num(String ph_num) 
	{
		return Pattern.matches("[6-9]{1}[0-9]{9}", ph_num);
	}
	public boolean valaadhar(String aadhar) 
	{
		return Pattern.matches("[0-9]{12}", aadhar);
	}
	public boolean valpin(String pin) 
	{
		return Pattern.matches("[0-9]{4}", pin);
	}

}