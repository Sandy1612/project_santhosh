package com.emp.service;

import static org.junit.Assert.*;

import org.junit.Test;

import com.emp.bean.Employee;

public class EmpServiceTest {

	Employee e=null;
	EmpService sr=null;
	
	
	@Test
	public void testCreateAccount() {
		e=new Employee();
		sr=new EmpService();
		e.setAcunt_num("12");
		e.setEname("sandy");
		boolean b = sr.createAccount(e);
		assertTrue("True",b);
	}

	@SuppressWarnings("deprecation")
	@Test
	public void testShowBalance() {
		e=new Employee();
		sr=new EmpService();
		e.setAcunt_num("12");
		e.setEname("sandy");
		sr.createAccount(e);
		assertEquals(0, sr.showBalance("12"));
	}

	@SuppressWarnings("deprecation")
	@Test
	public void testDeposite() {

		e=new Employee();
		sr=new EmpService();
		e.setAcunt_num("12");
		e.setEname("sandy");
		e.setBalance(500);
		sr.createAccount(e);
		sr.deposite(500, "12");
		assertEquals(1000, sr.showBalance("12"));

	
	
	}

	@SuppressWarnings("deprecation")
	@Test
	public void testWithdraw() {
		e=new Employee();
		sr=new EmpService();
		e.setAcunt_num("12");
		e.setEname("sandy");
		e.setBalance(10000);
		sr.createAccount(e);	
		sr.withdraw(9000, "12");
		assertEquals(1000, sr.showBalance("12"));
	
	}

	@Test
	public void testPrintTransaction() {
		e=new Employee();
		sr=new EmpService();
		e.setAcunt_num("12");
		e.setEname("sandy");
		e.setBalance(1000);
		e.setHist("Account opened\n");
		sr.createAccount(e);
		assertEquals("Account opened\n",e.getHist());
		
	
	}

	
}
